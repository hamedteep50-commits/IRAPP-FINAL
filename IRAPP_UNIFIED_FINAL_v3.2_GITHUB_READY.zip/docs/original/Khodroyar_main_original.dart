import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const Khodroyar());

class Khodroyar extends StatelessWidget {
  const Khodroyar({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'خودرویار',
        theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo),
        home: const HomePage(),
      );
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List vehicles = [], parts = [], faults = [], dtcs = [];
  String q = '', manufacturer = 'همه', fuel = 'همه';
  bool loading = true;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    vehicles = jsonDecode(await rootBundle.loadString('assets/data/vehicles.json'));
    parts = jsonDecode(await rootBundle.loadString('assets/data/parts.json'));
    faults = jsonDecode(await rootBundle.loadString('assets/data/faults.json'));
    dtcs = jsonDecode(await rootBundle.loadString('assets/data/dtc.json'));
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final makers = ['همه', ...vehicles.map((v) => v['manufacturer']).toSet().cast<String>()];
    final fuels = ['همه', ...vehicles.map((v) => (v['fuel'] ?? 'نامشخص').toString()).toSet()];
    final list = vehicles.where((v) {
      final text = '${v['manufacturer']} ${v['model']}'.toLowerCase();
      final okQ = text.contains(q.toLowerCase());
      final okM = manufacturer == 'همه' || v['manufacturer'] == manufacturer;
      final okF = fuel == 'همه' || (v['fuel'] ?? 'نامشخص').toString() == fuel;
      return okQ && okM && okF;
    }).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('خودرویار'), centerTitle: true,
          actions: [
            PopupMenuButton<String>(
              onSelected: (x) async {
                if (x == 'dtc') _openDtcSearch(context);
                if (x == 'vin') {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const VinPage()));
                }
                if (x == 'smart') {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => SmartSymptomPage(faults: faults)));
                }
                if (x == 'sources') {
                  final sources = jsonDecode(await rootBundle.loadString('assets/data/sources.json'));
                  if (context.mounted) {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => SourcesPage(sources: sources)));
                  }
                }
              },
              itemBuilder: (_) => const [
                PopupMenuItem(value: 'dtc', child: Text('جستجوی DTC')),
                PopupMenuItem(value: 'vin', child: Text('شناسایی با VIN')),
                PopupMenuItem(value: 'smart', child: Text('شرح عیب با زبان ساده')),
                PopupMenuItem(value: 'sources', child: Text('منابع و وضعیت داده')),
              ],
            ),
          ],
        ),
        body: Column(children: [
          Padding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 4), child: Column(children: [
            const Align(alignment: Alignment.centerRight, child: Text('دستیار هوشمند خودرو', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
            const Align(alignment: Alignment.centerRight, child: Text('خودرو را انتخاب کن یا عیب را مرحله‌به‌مرحله بررسی کن.')),
            const SizedBox(height: 12),
            TextField(
              onChanged: (x) => setState(() => q = x),
              decoration: InputDecoration(hintText: 'جستجوی خودرو...', prefixIcon: const Icon(Icons.search), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14))),
            ),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: _drop('سازنده', manufacturer, makers, (x) => setState(() => manufacturer = x!))),
              const SizedBox(width: 8),
              Expanded(child: _drop('سوخت', fuel, fuels, (x) => setState(() => fuel = x!))),
            ]),
          ])),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), child: Row(children: [
            _stat('خودرو', vehicles.length.toString(), Icons.directions_car),
            _stat('قطعه', parts.length.toString(), Icons.build),
            _stat('عیب', faults.length.toString(), Icons.search),
          ])),
          Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: SizedBox(width: double.infinity, child: OutlinedButton.icon(
            icon: const Icon(Icons.medical_services_outlined), label: const Text('شروع عیب‌یابی مرحله‌ای'),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SymptomWizard(vehicles: vehicles, faults: faults))),
          ))),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const VinPage()),
                    ),
                    icon: const Icon(Icons.qr_code_2),
                    label: const Text('VIN'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => SmartSymptomPage(faults: faults),
                      ),
                    ),
                    icon: const Icon(Icons.psychology_alt_outlined),
                    label: const Text('شرح عیب'),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Expanded(child: list.isEmpty
              ? const Center(child: Text('خودرویی با این فیلتر پیدا نشد.'))
              : ListView.builder(padding: const EdgeInsets.all(12), itemCount: list.length, itemBuilder: (c, i) {
                  final v = list[i];
                  final pending = v['spec_status'] != 'verified';
                  return Card(child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.directions_car)),
                    title: Text('${v['manufacturer']} — ${v['model']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(pending ? 'مشخصات دقیق: در انتظار راستی‌آزمایی' : 'مشخصات راستی‌آزمایی شده'),
                    trailing: const Icon(Icons.chevron_left),
                    onTap: () => Navigator.push(c, MaterialPageRoute(builder: (_) => VehiclePage(v: v, parts: parts, faults: faults, dtcs: dtcs))),
                  ));
                })),
        ]),
      ),
    );
  }

  Widget _drop(String label, String value, List<String> items, ValueChanged<String?> onChanged) => DropdownButtonFormField<String>(
    value: value, isExpanded: true, decoration: InputDecoration(labelText: label, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
    items: items.map((x) => DropdownMenuItem(value: x, child: Text(x, overflow: TextOverflow.ellipsis))).toList(), onChanged: onChanged,
  );

  Widget _stat(String a, String b, IconData i) => Expanded(child: Card(child: Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Column(children: [Icon(i), Text(b, style: const TextStyle(fontWeight: FontWeight.bold)), Text(a)]))));

  void _openDtcSearch(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (_) => DtcSearchPage(dtcs: dtcs)));
}

class VehiclePage extends StatelessWidget {
  final Map v; final List parts, faults, dtcs;
  const VehiclePage({super.key, required this.v, required this.parts, required this.faults, required this.dtcs});
  @override
  Widget build(BuildContext c) {
    final vp = parts.where((x) => x['vehicle_id'] == v['id']).toList();
    final vf = faults.where((x) => x['vehicle_id'] == v['id']).toList();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: Text(v['model'])),
      body: ListView(padding: const EdgeInsets.all(14), children: [
        Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(v['manufacturer'], style: Theme.of(c).textTheme.titleMedium),
          Text(v['model'], style: Theme.of(c).textTheme.headlineSmall),
          const SizedBox(height: 10),
          _info('سال', '${v['year_from'] ?? 'نامشخص'} تا ${v['year_to'] ?? 'نامشخص'}'),
          _info('موتور', '${v['engine'] ?? 'در انتظار منبع معتبر'}'),
          _info('سوخت', '${v['fuel'] ?? 'در انتظار منبع معتبر'}'),
          _info('گیربکس', '${v['transmission'] ?? 'در انتظار منبع معتبر'}'),
          const SizedBox(height: 8),
          Chip(avatar: const Icon(Icons.verified_outlined, size: 18), label: Text(v['spec_status'] ?? 'وضعیت نامشخص')),
        ]))),
        ExpansionTile(initiallyExpanded: true, title: Text('قطعات پایه (${vp.length})'), children: vp.map<Widget>((p) => ListTile(leading: const Icon(Icons.build_circle_outlined), title: Text(p['part']), subtitle: Text(p['system'] ?? 'قطعات پایه'))).toList()),
        ExpansionTile(title: Text('عیب‌یابی (${vf.length})'), children: vf.map<Widget>((f) => ListTile(leading: const Icon(Icons.search), title: Text(f['symptom']), subtitle: Text(f['diagnostic']))).toList()),
        ExpansionTile(title: Text('کدهای خطای پایه (${dtcs.length})'), children: dtcs.map<Widget>((d) => ListTile(leading: const Icon(Icons.warning_amber), title: Text(d['code']), subtitle: Text(d['meaning']))).toList()),
        const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('هشدار ایمنی: نتیجه عیب‌یابی فقط مسیر احتمالی تست است. برای ترمز، فرمان، سوخت، کیسه‌هوا و سامانه‌های ولتاژبالای خودروهای برقی، کار را به فرد واجد صلاحیت بسپارید.'))),
      ]),
    ));
  }
  Widget _info(String k, String v) => Padding(padding: const EdgeInsets.symmetric(vertical: 3), child: Row(children: [SizedBox(width: 90, child: Text(k, style: const TextStyle(fontWeight: FontWeight.bold))), Expanded(child: Text(v))]));
}

class DtcSearchPage extends StatefulWidget {
  final List dtcs; const DtcSearchPage({super.key, required this.dtcs});
  @override State<DtcSearchPage> createState() => _DtcSearchPageState();
}
class _DtcSearchPageState extends State<DtcSearchPage> {
  String q = '';
  @override Widget build(BuildContext context) {
    final list = widget.dtcs.where((d) => '${d['code']} ${d['meaning']}'.toLowerCase().contains(q.toLowerCase())).toList();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('جستجوی DTC')), body: Column(children: [
      Padding(padding: const EdgeInsets.all(14), child: TextField(onChanged: (x) => setState(() => q = x), decoration: const InputDecoration(hintText: 'مثلاً P0300', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()))),
      Expanded(child: ListView(children: list.map<Widget>((d) => ListTile(leading: const Icon(Icons.error_outline), title: Text(d['code']), subtitle: Text(d['meaning']))).toList())),
    ])));
  }
}

class SymptomWizard extends StatefulWidget {
  final List vehicles, faults; const SymptomWizard({super.key, required this.vehicles, required this.faults});
  @override State<SymptomWizard> createState() => _SymptomWizardState();
}
class _SymptomWizardState extends State<SymptomWizard> {
  String? vehicleId, symptom;
  final symptoms = const ['روشن نشدن خودرو', 'لرزش موتور', 'افت توان', 'خاموش شدن ناگهانی', 'افزایش مصرف سوخت', 'داغ کردن موتور', 'صدای غیرعادی'];
  @override Widget build(BuildContext context) {
    final vehicle = widget.vehicles.where((v) => v['id'] == vehicleId).cast<Map?>().firstWhere((x) => x != null, orElse: () => null);
    final matches = widget.faults.where((f) => (symptom == null || f['symptom'] == symptom) && (vehicleId == null || f['vehicle_id'] == vehicleId)).toList();
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('عیب‌یابی مرحله‌ای')), body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('مرحله ۱: خودرو', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      DropdownButtonFormField<String>(value: vehicleId, isExpanded: true, decoration: const InputDecoration(labelText: 'انتخاب خودرو', border: OutlineInputBorder()), items: widget.vehicles.map<DropdownMenuItem<String>>((v) => DropdownMenuItem(value: v['id'], child: Text('${v['manufacturer']} — ${v['model']}'))).toList(), onChanged: (x) => setState(() => vehicleId = x)),
      const SizedBox(height: 18),
      const Text('مرحله ۲: علامت اصلی', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      DropdownButtonFormField<String>(value: symptom, isExpanded: true, decoration: const InputDecoration(labelText: 'علامت خودرو', border: OutlineInputBorder()), items: symptoms.map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(), onChanged: (x) => setState(() => symptom = x)),
      const SizedBox(height: 18),
      if (vehicle != null) Card(child: Padding(padding: const EdgeInsets.all(12), child: Text('خودرو: ${vehicle['manufacturer']} ${vehicle['model']}'))),
      if (symptom != null) ...[
        const Text('مسیرهای پیشنهادی تست', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        if (matches.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(12), child: Text('برای این ترکیب هنوز مسیر اختصاصی ثبت نشده؛ از تست‌های پایه و DTC استفاده کنید.'))),
        ...matches.map((f) => Card(child: ListTile(leading: const Icon(Icons.route), title: Text(f['symptom']), subtitle: Text(f['diagnostic'])))),
      ],
      const SizedBox(height: 10),
      const Card(child: Padding(padding: EdgeInsets.all(12), child: Text('این بخش «تشخیص قطعی» نمی‌دهد؛ نتیجه بر اساس داده موجود، یک مسیر تست پیشنهادی است.'))),
    ]));
  }
}


class VinPage extends StatefulWidget {
  const VinPage({super.key});
  @override
  State<VinPage> createState() => _VinPageState();
}

class _VinPageState extends State<VinPage> {
  final controller = TextEditingController();
  String result = '';

  bool get valid => RegExp(r'^[A-HJ-NPR-Z0-9]{17}$').hasMatch(
        controller.text.trim().toUpperCase(),
      );

  void decode() {
    final vin = controller.text.trim().toUpperCase();
    setState(() {
      result = valid
          ? 'VIN معتبر است. در نسخه متصل به سرویس، این VIN برای دریافت مشخصات خودرو ارسال می‌شود.'
          : 'VIN باید دقیقاً ۱۷ کاراکتر باشد و شامل I، O یا Q نباشد.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('شناسایی با VIN')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'شماره VIN خودرو را وارد کنید',
              style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'این بخش برای اتصال بعدی به سرویس VIN و تطبیق خودرو با بانک خودرویار آماده شده است.',
            ),
            const SizedBox(height: 16),
            TextField(
              controller: controller,
              maxLength: 17,
              textCapitalization: TextCapitalization.characters,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                labelText: 'VIN',
                hintText: 'مثلاً 1HGCM82633A000000',
                border: OutlineInputBorder(),
              ),
            ),
            FilledButton.icon(
              onPressed: decode,
              icon: const Icon(Icons.manage_search),
              label: const Text('بررسی VIN'),
            ),
            if (result.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(14),
                  child: Text(result),
                ),
              ),
            const SizedBox(height: 12),
            const Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  'نکته: سرویس VIN منبع مستقل از بانک خودرویار است و ممکن است برای برخی خودروهای غیرآمریکایی اطلاعات محدودی برگرداند.',
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class SmartSymptomPage extends StatefulWidget {
  final List faults;
  const SmartSymptomPage({super.key, required this.faults});

  @override
  State<SmartSymptomPage> createState() => _SmartSymptomPageState();
}

class _SmartSymptomPageState extends State<SmartSymptomPage> {
  final controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final q = controller.text.trim().toLowerCase();
    final matches = q.isEmpty
        ? <dynamic>[]
        : widget.faults.where((f) {
            final s = '${f['symptom']} ${f['diagnostic']}'.toLowerCase();
            return s.contains(q);
          }).take(50).toList();

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('شرح عیب با زبان ساده')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(14),
              child: TextField(
                controller: controller,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  hintText: 'مثلاً ماشین صبح سخت روشن می‌شود',
                  prefixIcon: const Icon(Icons.psychology_alt_outlined),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
            ),
            Expanded(
              child: q.isEmpty
                  ? const Center(
                      child: Text(
                        'علامت یا شرح مشکل را بنویسید تا مسیرهای ثبت‌شده جستجو شوند.',
                        textAlign: TextAlign.center,
                      ),
                    )
                  : matches.isEmpty
                      ? const Center(child: Text('مورد مشابهی در داده فعلی پیدا نشد.'))
                      : ListView.builder(
                          itemCount: matches.length,
                          itemBuilder: (_, i) {
                            final f = matches[i];
                            return Card(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 12,
                                vertical: 5,
                              ),
                              child: ListTile(
                                leading: const Icon(Icons.route_outlined),
                                title: Text('${f['symptom']}'),
                                subtitle: Text('${f['diagnostic']}'),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class SourcesPage extends StatelessWidget {
  final List sources;
  const SourcesPage({super.key, required this.sources});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('منابع و وضعیت داده')),
        body: ListView(
          padding: const EdgeInsets.all(12),
          children: [
            const Card(
              child: Padding(
                padding: EdgeInsets.all(14),
                child: Text(
                  'خودرویار نباید مشخصات فنی، موتور، گیربکس یا شماره قطعه را حدس بزند. موارد تأییدنشده باید تا زمان راستی‌آزمایی با برچسب «در انتظار منبع معتبر» نمایش داده شوند.',
                ),
              ),
            ),
            ...sources.map(
              (s) => Card(
                child: ListTile(
                  leading: const Icon(Icons.source_outlined),
                  title: Text('${s['name'] ?? 'منبع'}'),
                  subtitle: Text(
                    '${s['url'] ?? ''}\n${s['type'] ?? ''}',
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
