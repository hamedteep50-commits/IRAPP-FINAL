# IRAPP v4.3.0 MASTER
- معماری جامع Android / iOS / iPadOS / Windows / Linux / macOS / Web / Tablet
- Offline-first و صف همگام‌سازی
- مرکز ذخیره‌سازی کاربر و مدیریت
- Server/API client: health, login, token, sync
- پیکربندی Server URL بدون آدرس جعلی
- تحویل امن نرم‌افزار و License architecture
- قرارداد Server/API و مستندات امنیتی
- Web/PWA assets کامل‌تر برای اجرای مستقل
- حفظ قابلیت‌های v4.1.1 تا v4.2.2
