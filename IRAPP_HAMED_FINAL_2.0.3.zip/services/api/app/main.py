from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from datetime import datetime
from uuid import uuid4

app = FastAPI(title='IRAPP API', version='1.0.0')
apps=[]
reports=[]

class AppSubmission(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    package_name: str = Field(min_length=3, max_length=200)
    developer: str = Field(min_length=2, max_length=100)

@app.get('/health')
def health():
    return {'status':'ok','service':'irapp-api','time':datetime.utcnow().isoformat()}

@app.get('/apps')
def list_apps():
    return apps

@app.post('/developer/apps', status_code=201)
def submit_app(item: AppSubmission):
    record={'id':str(uuid4()), **item.model_dump(), 'status':'pending_security_review', 'created_at':datetime.utcnow().isoformat()}
    apps.append(record)
    return record

@app.post('/security/report')
def security_report(payload: dict):
    reports.append({'id':str(uuid4()), 'payload':payload, 'created_at':datetime.utcnow().isoformat()})
    return {'accepted':True,'queue':'security_review'}

@app.get('/admin/summary')
def admin_summary():
    return {'apps_total':len(apps),'pending_security_review':sum(1 for x in apps if x['status']=='pending_security_review'),'security_reports':len(reports),'ai_manager_modes':['semi_automatic','emergency']}
