# IRAPP release rules. Keep empty until obfuscation is enabled.
