# IRAPP v1.0 — Android Ready

نسخه مرتب‌شده پروژه IRAPP برای ساخت APK اندروید.

## ساخت APK در GitHub

1. محتویات این پروژه را در یک مخزن GitHub قرار دهید.
2. از بخش **Actions**، workflow با نام **Build IRAPP APK** را اجرا کنید.
3. پس از پایان موفق، از بخش **Artifacts** فایل `IRAPP-debug-apk` را دریافت کنید.
4. برای انتشار عمومی، نسخه Release را با کلید امضای اختصاصی پروژه build/sign کنید.

## ساخت با Android Studio

پوشه `apps/android` را در Android Studio باز کنید و پروژه را Sync/Build کنید.

مشخصات اصلی:
- Application ID: `com.irapp.store`
- Version: `1.0.0`
- Min SDK: 23
- Target/Compile SDK: 35
- Java: 17
- Gradle: 8.6
