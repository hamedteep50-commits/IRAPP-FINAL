# معماری پیشنهادی

Client (Web/Mobile/Desktop) -> API Gateway -> Auth / Catalog / Developer / Admin / Security modules -> Database & Object Storage.

اصول: حداقل‌سازی داده، کنترل دسترسی مبتنی بر نقش، ثبت رویداد، اسکن فایل قبل از انتشار، صف بررسی انسانی برای موارد حساس.
