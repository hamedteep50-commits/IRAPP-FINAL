# IRAPP v4.3.1 — Supabase connection preparation
- Default project URL configured for Supabase.
- Supabase Auth password sign-in uses email/password and access token.
- Connection test uses Supabase Auth health endpoint.
- Cloud snapshot upsert uses `irapp_cloud_snapshots` and requires the included SQL migration.
- Publishable key only; no secret/service_role key included.
- Build/APK has not been executed or device-tested in this environment.
