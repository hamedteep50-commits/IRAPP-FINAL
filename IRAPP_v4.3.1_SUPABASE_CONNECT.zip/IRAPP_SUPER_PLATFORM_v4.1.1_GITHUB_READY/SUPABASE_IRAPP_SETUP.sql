-- IRAPP cloud snapshot table for Supabase
-- Run once in Supabase SQL Editor. Uses user-scoped RLS.
create table if not exists public.irapp_cloud_snapshots (
  user_id uuid primary key references auth.users(id) on delete cascade,
  snapshot jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.irapp_cloud_snapshots enable row level security;
drop policy if exists "Users can read own IRAPP snapshot" on public.irapp_cloud_snapshots;
create policy "Users can read own IRAPP snapshot" on public.irapp_cloud_snapshots for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Users can insert own IRAPP snapshot" on public.irapp_cloud_snapshots;
create policy "Users can insert own IRAPP snapshot" on public.irapp_cloud_snapshots for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Users can update own IRAPP snapshot" on public.irapp_cloud_snapshots;
create policy "Users can update own IRAPP snapshot" on public.irapp_cloud_snapshots for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);
grant select, insert, update on public.irapp_cloud_snapshots to authenticated;
