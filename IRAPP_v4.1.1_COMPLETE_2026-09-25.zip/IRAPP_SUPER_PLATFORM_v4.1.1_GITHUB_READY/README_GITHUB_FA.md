# IRAPP SUPER PLATFORM v4.1.1 — GitHub Ready

نسخه: 4.1.1
تاریخ پاکسازی: 2026-09-24

## مبنا
این بسته همان `IRAPP_SUPER_PLATFORM_v4.1.1_GITHUB_READY.zip` است و نسخه‌های قدیمی مبنا نیستند.

## کنترل‌های انجام‌شده
- ساختار پروژه Android بررسی شد.
- `settings.gradle`، `build.gradle` و `app/build.gradle` بررسی شدند.
- Android SDK 35، JDK 17 و AGP 8.6.1 بررسی شدند.
- `applicationId=com.irapp.store` و نسخه Android برابر 4.1.1 / versionCode 411 است.
- JavaScript از نظر syntax بررسی شد.
- actionهای HTML با handlerهای JavaScript تطبیق داده شدند.
- داده‌های محلی خودرویار شامل 200 خودرو، 3000 قطعه و 2000 رکورد عیب/تشخیص در بسته حفظ شده‌اند.
- مستندات و cache وب از ارجاعات stale نسخه‌های 3.3.x و 4.1.0 پاکسازی شدند.

## Build
Workflow در `.github/workflows/build.yml` از JDK 17، Android SDK 35 و Gradle 8.7 استفاده می‌کند و APK debug را به عنوان Artifact منتشر می‌کند.

> نکته: این پروژه در ZIP فعلی Gradle Wrapper ندارد؛ بنابراین Workflow از `gradle/actions/setup-gradle@v4` برای فراهم‌کردن Gradle 8.7 استفاده می‌کند. افزودن Wrapper واقعی نیازمند تولید فایل `gradle-wrapper.jar` با یک نصب Gradle است.

## قابلیت‌های آنلاین
Backend واقعی، احراز هویت، چت، پرداخت، انتشار APK و همگام‌سازی ابری هنوز باید به API امن متصل شوند؛ داده‌های محلی به‌عنوان سرویس آنلاین واقعی معرفی نشده‌اند.
