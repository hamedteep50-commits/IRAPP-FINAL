# IRAPP SUPER PLATFORM v4.1.1 — 2026-09-24

## وضعیت نسخه
- نسخه Android: 4.1.1 / versionCode 411
- مبنای کار: IRAPP Unified Final و ادغام IRAPP، بازار، خودرویار و HAMED AI
- پوسته Web/PWA در پروژه حفظ شده است.
- قابلیت‌های آنلاین واقعی مانند Backend، احراز هویت، چت، پرداخت و انتشار APK هنوز نیازمند اتصال به API امن هستند.

## کنترل فنی
- ساختار Gradle بررسی شد.
- JavaScript از نظر syntax بررسی شد.
- actionهای HTML با handlerهای JavaScript تطبیق داده شدند.
- Workflow برای JDK 17، Android SDK 35 و Gradle 8.7 تنظیم شده است.
- این بسته برای انتقال به GitHub آماده‌سازی شده و قبل از انتشار باید Build واقعی در GitHub Actions موفق شود.
